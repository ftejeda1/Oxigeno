import React, { useState } from 'react';
import { Plus, Edit, Trash2, Settings, Save, X } from 'lucide-react';

interface Classroom {
  id: string;
  name: string;
  building: string;
}

interface Sensor {
  id: string;
  type: string;
  classroomId: string;
  status: 'active' | 'inactive' | 'maintenance';
}

interface Threshold {
  metric: string;
  good: { min: number; max: number };
  moderate: { min: number; max: number };
  poor: { min: number; max: number };
}

const ConfigPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'classrooms' | 'sensors' | 'thresholds'>('classrooms');
  const [classrooms, setClassrooms] = useState<Classroom[]>([
    { id: '1', name: 'Aula 101', building: 'Edificio A' },
    { id: '2', name: 'Aula 102', building: 'Edificio A' },
    { id: '3', name: 'Laboratorio 201', building: 'Edificio B' },
  ]);

  const [sensors, setSensors] = useState<Sensor[]>([
    { id: '1', type: 'CO₂', classroomId: '1', status: 'active' },
    { id: '2', type: 'PM2.5', classroomId: '1', status: 'active' },
    { id: '3', type: 'Temperatura', classroomId: '1', status: 'active' },
    { id: '4', type: 'Humedad', classroomId: '1', status: 'maintenance' },
  ]);

  const [thresholds, setThresholds] = useState<Threshold[]>([
    { 
      metric: 'CO₂', 
      good: { min: 0, max: 600 }, 
      moderate: { min: 600, max: 800 }, 
      poor: { min: 800, max: 1000 } 
    },
    { 
      metric: 'PM2.5', 
      good: { min: 0, max: 12 }, 
      moderate: { min: 12, max: 25 }, 
      poor: { min: 25, max: 35 } 
    },
  ]);

  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<any>({});

  const startEdit = (type: string, item: any) => {
    setIsEditing(`${type}-${item.id}`);
    setEditForm({ ...item });
  };

  const cancelEdit = () => {
    setIsEditing(null);
    setEditForm({});
  };

  const saveEdit = (type: string) => {
    if (type === 'classroom') {
      setClassrooms(classrooms.map(c => c.id === editForm.id ? editForm : c));
    } else if (type === 'sensor') {
      setSensors(sensors.map(s => s.id === editForm.id ? editForm : s));
    } else if (type === 'threshold') {
      setThresholds(thresholds.map(t => t.metric === editForm.metric ? editForm : t));
    }
    setIsEditing(null);
    setEditForm({});
  };

  const deleteItem = (type: string, id: string) => {
    if (type === 'classroom') {
      setClassrooms(classrooms.filter(c => c.id !== id));
    } else if (type === 'sensor') {
      setSensors(sensors.filter(s => s.id !== id));
    }
  };

  const addClassroom = () => {
    const newId = (Math.max(...classrooms.map(c => parseInt(c.id))) + 1).toString();
    setClassrooms([...classrooms, { id: newId, name: '', building: '' }]);
    setIsEditing(`classroom-${newId}`);
    setEditForm({ id: newId, name: '', building: '' });
  };

  const renderClassrooms = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium text-gray-900">Gestión de Aulas</h3>
        <button
          onClick={addClassroom}
          className="bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Añadir Aula</span>
        </button>
      </div>

      <div className="bg-white rounded-lg border">
        <div className="overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Nombre
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Edificio
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {classrooms.map((classroom) => (
                <tr key={classroom.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {isEditing === `classroom-${classroom.id}` ? (
                      <input
                        type="text"
                        value={editForm.name}
                        onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                        className="border border-gray-300 rounded-md px-3 py-1 text-sm w-full"
                        placeholder="Nombre del aula"
                      />
                    ) : (
                      <div className="text-sm font-medium text-gray-900">{classroom.name}</div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {isEditing === `classroom-${classroom.id}` ? (
                      <input
                        type="text"
                        value={editForm.building}
                        onChange={(e) => setEditForm({ ...editForm, building: e.target.value })}
                        className="border border-gray-300 rounded-md px-3 py-1 text-sm w-full"
                        placeholder="Edificio"
                      />
                    ) : (
                      <div className="text-sm text-gray-900">{classroom.building}</div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {isEditing === `classroom-${classroom.id}` ? (
                      <div className="flex justify-end space-x-2">
                        <button
                          onClick={() => saveEdit('classroom')}
                          className="text-green-600 hover:text-green-900"
                        >
                          <Save className="w-4 h-4" />
                        </button>
                        <button
                          onClick={cancelEdit}
                          className="text-gray-600 hover:text-gray-900"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex justify-end space-x-2">
                        <button
                          onClick={() => startEdit('classroom', classroom)}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteItem('classroom', classroom.id)}
                          className="text-red-600 hover:text-red-900"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderSensors = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium text-gray-900">Gestión de Sensores</h3>
      </div>

      <div className="bg-white rounded-lg border">
        <div className="overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tipo
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Aula
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Estado
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sensors.map((sensor) => {
                const classroom = classrooms.find(c => c.id === sensor.classroomId);
                return (
                  <tr key={sensor.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{sensor.type}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{classroom?.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        sensor.status === 'active' ? 'bg-green-100 text-green-800' :
                        sensor.status === 'maintenance' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {sensor.status === 'active' ? 'Activo' :
                         sensor.status === 'maintenance' ? 'Mantenimiento' : 'Inactivo'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => startEdit('sensor', sensor)}
                        className="text-blue-600 hover:text-blue-900 mr-2"
                      >
                        <Settings className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderThresholds = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium text-gray-900">Configuración de Umbrales</h3>
      </div>

      <div className="space-y-6">
        {thresholds.map((threshold) => (
          <div key={threshold.metric} className="bg-white p-6 rounded-lg border">
            <h4 className="text-lg font-medium text-gray-900 mb-4">{threshold.metric}</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <h5 className="font-medium text-green-800 mb-2">Buena</h5>
                <div className="space-y-2">
                  <div>
                    <label className="block text-xs text-green-700">Mínimo</label>
                    <input
                      type="number"
                      value={threshold.good.min}
                      onChange={(e) => {
                        const newThresholds = thresholds.map(t => 
                          t.metric === threshold.metric 
                            ? { ...t, good: { ...t.good, min: Number(e.target.value) }}
                            : t
                        );
                        setThresholds(newThresholds);
                      }}
                      className="w-full border border-green-300 rounded px-2 py-1 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-green-700">Máximo</label>
                    <input
                      type="number"
                      value={threshold.good.max}
                      onChange={(e) => {
                        const newThresholds = thresholds.map(t => 
                          t.metric === threshold.metric 
                            ? { ...t, good: { ...t.good, max: Number(e.target.value) }}
                            : t
                        );
                        setThresholds(newThresholds);
                      }}
                      className="w-full border border-green-300 rounded px-2 py-1 text-sm"
                    />
                  </div>
                </div>
              </div>

              <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <h5 className="font-medium text-yellow-800 mb-2">Moderada</h5>
                <div className="space-y-2">
                  <div>
                    <label className="block text-xs text-yellow-700">Mínimo</label>
                    <input
                      type="number"
                      value={threshold.moderate.min}
                      onChange={(e) => {
                        const newThresholds = thresholds.map(t => 
                          t.metric === threshold.metric 
                            ? { ...t, moderate: { ...t.moderate, min: Number(e.target.value) }}
                            : t
                        );
                        setThresholds(newThresholds);
                      }}
                      className="w-full border border-yellow-300 rounded px-2 py-1 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-yellow-700">Máximo</label>
                    <input
                      type="number"
                      value={threshold.moderate.max}
                      onChange={(e) => {
                        const newThresholds = thresholds.map(t => 
                          t.metric === threshold.metric 
                            ? { ...t, moderate: { ...t.moderate, max: Number(e.target.value) }}
                            : t
                        );
                        setThresholds(newThresholds);
                      }}
                      className="w-full border border-yellow-300 rounded px-2 py-1 text-sm"
                    />
                  </div>
                </div>
              </div>

              <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
                <h5 className="font-medium text-orange-800 mb-2">Mala</h5>
                <div className="space-y-2">
                  <div>
                    <label className="block text-xs text-orange-700">Mínimo</label>
                    <input
                      type="number"
                      value={threshold.poor.min}
                      onChange={(e) => {
                        const newThresholds = thresholds.map(t => 
                          t.metric === threshold.metric 
                            ? { ...t, poor: { ...t.poor, min: Number(e.target.value) }}
                            : t
                        );
                        setThresholds(newThresholds);
                      }}
                      className="w-full border border-orange-300 rounded px-2 py-1 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-orange-700">Máximo</label>
                    <input
                      type="number"
                      value={threshold.poor.max}
                      onChange={(e) => {
                        const newThresholds = thresholds.map(t => 
                          t.metric === threshold.metric 
                            ? { ...t, poor: { ...t.poor, max: Number(e.target.value) }}
                            : t
                        );
                        setThresholds(newThresholds);
                      }}
                      className="w-full border border-orange-300 rounded px-2 py-1 text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Configuración del Sistema</h2>

      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('classrooms')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'classrooms'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Aulas
          </button>
          <button
            onClick={() => setActiveTab('sensors')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'sensors'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Sensores
          </button>
          <button
            onClick={() => setActiveTab('thresholds')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'thresholds'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Umbrales
          </button>
        </nav>
      </div>

      <div className="mt-6">
        {activeTab === 'classrooms' && renderClassrooms()}
        {activeTab === 'sensors' && renderSensors()}
        {activeTab === 'thresholds' && renderThresholds()}
      </div>
    </div>
  );
};

export default ConfigPanel;