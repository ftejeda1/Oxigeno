export interface ClassroomData {
  id: string;
  name: string;
  building: string;
  co2: number;
  pm25: number;
  temperature: number;
  humidity: number;
  lastUpdated: Date;
  trend24h: Array<{ time: Date; co2: number; pm25: number; temperature: number; humidity: number }>;
}

export interface Alert {
  id: string;
  classroomId: string;
  classroomName: string;
  type: 'co2' | 'pm25' | 'temperature' | 'humidity';
  level: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: Date;
  resolved: boolean;
}

// Generate mock trend data for the last 24 hours
const generateTrendData = () => {
  const data = [];
  const now = new Date();
  for (let i = 23; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 60 * 60 * 1000);
    data.push({
      time,
      co2: 400 + Math.random() * 800, // 400-1200 ppm
      pm25: Math.random() * 50, // 0-50 μg/m³
      temperature: 20 + Math.random() * 8, // 20-28°C
      humidity: 40 + Math.random() * 40, // 40-80%
    });
  }
  return data;
};

export const mockClassrooms: ClassroomData[] = [
  {
    id: '1',
    name: 'Aula 101',
    building: 'Edificio A',
    co2: 650,
    pm25: 15,
    temperature: 23.5,
    humidity: 55,
    lastUpdated: new Date(),
    trend24h: generateTrendData(),
  },
  {
    id: '2',
    name: 'Aula 102',
    building: 'Edificio A',
    co2: 890,
    pm25: 28,
    temperature: 24.8,
    humidity: 62,
    lastUpdated: new Date(),
    trend24h: generateTrendData(),
  },
  {
    id: '3',
    name: 'Laboratorio 201',
    building: 'Edificio B',
    co2: 1150,
    pm25: 35,
    temperature: 22.1,
    humidity: 48,
    lastUpdated: new Date(),
    trend24h: generateTrendData(),
  },
  {
    id: '4',
    name: 'Aula Magna',
    building: 'Edificio C',
    co2: 420,
    pm25: 8,
    temperature: 23.2,
    humidity: 58,
    lastUpdated: new Date(),
    trend24h: generateTrendData(),
  },
  {
    id: '5',
    name: 'Aula 301',
    building: 'Edificio B',
    co2: 780,
    pm25: 22,
    temperature: 25.1,
    humidity: 65,
    lastUpdated: new Date(),
    trend24h: generateTrendData(),
  },
  {
    id: '6',
    name: 'Sala de Conferencias',
    building: 'Edificio C',
    co2: 520,
    pm25: 12,
    temperature: 22.8,
    humidity: 51,
    lastUpdated: new Date(),
    trend24h: generateTrendData(),
  },
];

export const mockAlerts: Alert[] = [
  {
    id: '1',
    classroomId: '3',
    classroomName: 'Laboratorio 201',
    type: 'co2',
    level: 'critical',
    message: 'Nivel de CO₂ crítico: 1150 ppm',
    timestamp: new Date(Date.now() - 10 * 60 * 1000),
    resolved: false,
  },
  {
    id: '2',
    classroomId: '2',
    classroomName: 'Aula 102',
    type: 'pm25',
    level: 'medium',
    message: 'PM2.5 elevado: 28 μg/m³',
    timestamp: new Date(Date.now() - 25 * 60 * 1000),
    resolved: false,
  },
  {
    id: '3',
    classroomId: '5',
    classroomName: 'Aula 301',
    type: 'humidity',
    level: 'low',
    message: 'Humedad alta: 65%',
    timestamp: new Date(Date.now() - 45 * 60 * 1000),
    resolved: false,
  },
  {
    id: '4',
    classroomId: '1',
    classroomName: 'Aula 101',
    type: 'temperature',
    level: 'low',
    message: 'Temperatura revisada',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    resolved: true,
  },
];

export const getQualityLevel = (type: string, value: number): 'good' | 'moderate' | 'poor' | 'critical' => {
  switch (type) {
    case 'co2':
      if (value < 600) return 'good';
      if (value < 800) return 'moderate';
      if (value < 1000) return 'poor';
      return 'critical';
    case 'pm25':
      if (value < 12) return 'good';
      if (value < 25) return 'moderate';
      if (value < 35) return 'poor';
      return 'critical';
    case 'temperature':
      if (value >= 20 && value <= 25) return 'good';
      if (value >= 18 && value <= 28) return 'moderate';
      if (value >= 15 && value <= 30) return 'poor';
      return 'critical';
    case 'humidity':
      if (value >= 40 && value <= 60) return 'good';
      if (value >= 30 && value <= 70) return 'moderate';
      if (value >= 20 && value <= 80) return 'poor';
      return 'critical';
    default:
      return 'good';
  }
};

export const getQualityColor = (level: string): string => {
  switch (level) {
    case 'good': return 'text-green-600 bg-green-50 border-green-200';
    case 'moderate': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    case 'poor': return 'text-orange-600 bg-orange-50 border-orange-200';
    case 'critical': return 'text-red-600 bg-red-50 border-red-200';
    default: return 'text-gray-600 bg-gray-50 border-gray-200';
  }
};